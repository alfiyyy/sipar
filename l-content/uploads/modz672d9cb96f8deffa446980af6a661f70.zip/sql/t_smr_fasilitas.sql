#
# TABLE STRUCTURE FOR: t_smr_fasilitas
#

DROP TABLE IF EXISTS `t_smr_fasilitas`;

CREATE TABLE `t_smr_fasilitas` (
  `smrf_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unker_id` int(11) DEFAULT NULL,
  `smrf_nama` varchar(100) DEFAULT '',
  `smrf_icon` varchar(100) DEFAULT '',
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`smrf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `t_smr_fasilitas` (`smrf_id`, `unker_id`, `smrf_nama`, `smrf_icon`, `created_at`, `updated_at`) VALUES (1, 2, 'Televisi', 'tv', '2021-11-18', '0000-00-00');
INSERT INTO `t_smr_fasilitas` (`smrf_id`, `unker_id`, `smrf_nama`, `smrf_icon`, `created_at`, `updated_at`) VALUES (2, 2, 'AC', 'snowflake-o', '2021-11-18', '0000-00-00');


