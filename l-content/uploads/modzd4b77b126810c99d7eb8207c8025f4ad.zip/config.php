<?php
/**
 * - Ini adalah file konfigurasi instalasi komponen CiFireCMS.
 * - Komponen   : Kelola Smart Meeting
 * - Tanggal    : 2021-12-16 | 10:37 AM
*/

$_config['component_name']  = 'Kelola Smart Meeting';
$_config['class_name']      = 'kelola_smart_meeting';
$_config['table_name']      = 't_smr';
$_config['file_sql']        = 't_smr.sql';
$_config['file_controller'] = 'Kelola_smart_meeting.php';
$_config['file_model']      = 'Kelola_smart_meeting_model.php';
$_config['dir_views']       = 'kelola-smart-meeting';
$_config['file_modjs']      = 'kelola-smart-meeting.js';
$_config['mod']             = 'kelola-smart-meeting';