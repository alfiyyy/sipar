<?php
/**
 * - Ini adalah file konfigurasi instalasi komponen CiFireCMS.
 * - Komponen   : SMR Fasilitas
 * - Tanggal    : 2022-01-08 | 10:07 AM
*/

$_config['component_name']  = 'SMR Fasilitas';
$_config['class_name']      = 'smr_fasilitas';
$_config['table_name']      = 't_smr_fasilitas';
$_config['file_sql']        = 't_smr_fasilitas.sql';
$_config['file_controller'] = 'Smr_fasilitas.php';
$_config['file_model']      = 'Smr_fasilitas_model.php';
$_config['dir_views']       = 'smr-fasilitas';
$_config['file_modjs']      = 'smr-fasilitas.js';
$_config['mod']             = 'smr-fasilitas';