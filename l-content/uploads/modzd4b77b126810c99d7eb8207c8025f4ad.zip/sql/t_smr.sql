#
# TABLE STRUCTURE FOR: t_smr
#

DROP TABLE IF EXISTS `t_smr`;

CREATE TABLE `t_smr` (
  `smr_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unker_id` int(11) DEFAULT NULL,
  `smr_nama` varchar(255) DEFAULT '',
  `smr_nomor` int(5) DEFAULT NULL,
  `smr_kapasitas` varchar(20) DEFAULT '',
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`smr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `t_smr` (`smr_id`, `unker_id`, `smr_nama`, `smr_nomor`, `smr_kapasitas`, `created_at`, `updated_at`) VALUES (1, 2, 'SMR Kencana', 1, '10', '2021-11-18', '2021-11-18');
INSERT INTO `t_smr` (`smr_id`, `unker_id`, `smr_nama`, `smr_nomor`, `smr_kapasitas`, `created_at`, `updated_at`) VALUES (2, 2, 'SMR Kencana', 2, '20', '2021-11-18', '0000-00-00');
INSERT INTO `t_smr` (`smr_id`, `unker_id`, `smr_nama`, `smr_nomor`, `smr_kapasitas`, `created_at`, `updated_at`) VALUES (3, 2, 'SMR Kencana', 3, '20', '2021-11-19', '0000-00-00');
INSERT INTO `t_smr` (`smr_id`, `unker_id`, `smr_nama`, `smr_nomor`, `smr_kapasitas`, `created_at`, `updated_at`) VALUES (4, 3, 'Sriwijaya', 1, '20', '2021-11-19', '0000-00-00');


